"""
storage.py
----------
Handles writing crawled pages to WARC (Web ARChive) files compressed
with gzip, following the Storage Policy:

  - 1,000 pages per WARC file.
  - Files named  warcs/crawl-NNNNN.warc.gz  (zero-padded 5-digit index).
  - A threading.Lock serialises all writes so that concurrent worker
    threads never interleave records inside the same file.

WARC format overview:
  Each WARC file is a sequence of records.  We write two record types:
    - WARC-Type: warcinfo   (one per file, metadata about the crawl)
    - WARC-Type: response   (one per crawled page, contains HTTP headers
                             + HTML body)

  The warcio library handles the binary serialisation and gzip streaming.

Complexity:
  - write()   : O(n) in the size of the HTML page (one disk write).
  - Rotation  : O(1) — just close the old WARCWriter and open a new one.
"""

import io
import os
import logging
import threading
from datetime import datetime, timezone

from warcio.warcwriter import WARCWriter
from warcio.statusandheaders import StatusAndHeaders

logger = logging.getLogger(__name__)

PAGES_PER_FILE: int = 1_000
WARC_DIR: str = "warcs"


class StorageManager:
    """
    Thread-safe WARC writer that rotates files every PAGES_PER_FILE pages.

    Usage
    -----
        storage = StorageManager()
        storage.write(fetch_result)
        ...
        storage.close()
    """

    def __init__(self, output_dir: str = WARC_DIR) -> None:
        """
        Parameters
        ----------
        output_dir : str
            Directory where WARC files will be written. Created if absent.
        """
        self._output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        self._lock = threading.Lock()      # serialises access to the writer
        self._file_index: int = 0          # current WARC file number
        self._pages_in_file: int = 0       # pages written to the current file
        self._total_pages: int = 0         # grand total across all files

        self._warc_file = None             # open file handle
        self._writer: WARCWriter | None = None

        self._open_new_file()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def write(self, url: str, html: bytes, http_headers: dict) -> None:
        """
        Append one crawled page to the current WARC file.

        If the current file has reached PAGES_PER_FILE pages, it is closed
        and a new one is opened before writing.

        Parameters
        ----------
        url          : Final URL of the fetched page (after redirects).
        html         : Raw HTML bytes.
        http_headers : HTTP response headers dict (from requests).
        """
        with self._lock:
            if self._pages_in_file >= PAGES_PER_FILE:
                self._rotate()

            self._write_record(url, html, http_headers)
            self._pages_in_file += 1
            self._total_pages += 1

    def close(self) -> None:
        """Flush and close the current WARC file."""
        with self._lock:
            self._close_current_file()

    @property
    def total_pages(self) -> int:
        """Total number of pages written so far (thread-safe read)."""
        with self._lock:
            return self._total_pages

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _open_new_file(self) -> None:
        """
        Open a new gzip-compressed WARC file and write a warcinfo record.

        File names: warcs/crawl-00000.warc.gz, crawl-00001.warc.gz, …
        """
        filename = os.path.join(
            self._output_dir, f"crawl-{self._file_index:05d}.warc.gz"
        )
        self._warc_file = open(filename, "wb")
        self._writer = WARCWriter(self._warc_file, gzip=True)

        # Write mandatory warcinfo record (metadata about this crawl)
        info_headers = {
            "software": "IR-Crawler/1.0",
            "robots": "obey",
            "hostname": "crawler",
            "operator": "UFMG IR Assignment 1",
            "format": "WARC File Format 1.0",
        }
        record = self._writer.create_warcinfo_record(
            filename=filename, info=info_headers
        )
        self._writer.write_record(record)
        logger.debug("Opened WARC file: %s", filename)

    def _close_current_file(self) -> None:
        """Close the current WARC file handles."""
        if self._warc_file:
            self._warc_file.flush()
            self._warc_file.close()
            self._warc_file = None
            self._writer = None

    def _rotate(self) -> None:
        """Close the current file and open the next one."""
        self._close_current_file()
        self._file_index += 1
        self._pages_in_file = 0
        self._open_new_file()

    def _write_record(self, url: str, html: bytes, http_headers: dict) -> None:
        """
        Write a single WARC response record.

        The record structure follows the WARC 1.0 specification:
          - WARC headers (URL, date, content-type, …)
          - HTTP status line + headers
          - HTML body
        """
        # Build the HTTP status + headers block that WARC embeds
        status_line = http_headers.get("Status", "200 OK")
        warc_http_headers = StatusAndHeaders(
            statusline=status_line,
            headers=list(http_headers.items()),
            protocol="HTTP/1.1",
        )

        # ISO 8601 timestamp required by the WARC format
        warc_date = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        record = self._writer.create_warc_record(
            uri=url,
            record_type="response",
            payload=io.BytesIO(html),
            length=len(html),
            http_headers=warc_http_headers,
            warc_headers_dict={
                "WARC-Date": warc_date,
                "WARC-Target-URI": url,
            },
        )
        self._writer.write_record(record)
