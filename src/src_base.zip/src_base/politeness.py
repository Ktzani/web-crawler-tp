"""
politeness.py
-------------
Enforces the Politeness Policy defined in the assignment:

  1. Respect the robots exclusion protocol (robots.txt) via Protego.
  2. Enforce a minimum delay of 100 ms between consecutive requests to the
     same host (or the Crawl-delay value from robots.txt if larger).

Data structures:
  - dict[host -> Protego]        : cached robots parsers. O(1) lookup.
  - dict[host -> float]          : timestamp of last request per host. O(1).
  - dict[host -> threading.Lock] : one lock per host so threads targeting
                                   different hosts never block each other.
  - threading.Lock               : guards the three dicts above during init.
"""

import time
import threading
import logging

import requests
from protego import Protego

logger = logging.getLogger(__name__)

# Delay applied when robots.txt is absent or has no Crawl-delay directive
DEFAULT_DELAY: float = 0.1          # 100 ms

# Timeout for fetching robots.txt (seconds)
ROBOTS_FETCH_TIMEOUT: int = 5

# User-agent string sent on every request (including robots.txt fetches)
USER_AGENT: str = "IR-Crawler/1.0 (+https://dcc.ufmg.br)"


class PolitenessManager:
    """
    Per-host politeness enforcement.

    All public methods are thread-safe.
    """

    def __init__(self) -> None:
        # robots.txt parser cache: host -> Protego instance (or None if fetch failed)
        self._robots: dict[str, Protego | None] = {}
        # Unix timestamp of the last completed request to each host
        self._last_access: dict[str, float] = {}
        # One lock per host (created lazily); guards both _robots and _last_access
        self._host_locks: dict[str, threading.Lock] = {}
        # Guards the dicts themselves during lazy initialisation
        self._global_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def is_allowed(self, url: str) -> bool:
        """
        Return True if our user-agent is allowed to fetch *url*.

        Fetches and caches the host's robots.txt on first call.
        A failed robots.txt fetch is treated as "allow all".

        Parameters
        ----------
        url : str
            The absolute URL to check.
        """
        host = self._host_of(url)
        lock = self._get_host_lock(host)

        with lock:
            robots = self._get_robots(host)

        if robots is None:
            # Could not fetch robots.txt -> allow
            return True

        return robots.can_fetch(url, USER_AGENT)

    def wait_if_needed(self, url: str) -> None:
        """
        Block the calling thread until it is polite to fetch *url*.

        Computes the required delay as:
            max(DEFAULT_DELAY, crawl_delay_from_robots_txt)
        then sleeps for any remaining time since the last request to
        the same host.
        """
        host = self._host_of(url)
        lock = self._get_host_lock(host)

        with lock:
            delay = self._crawl_delay(host)
            last = self._last_access.get(host, 0.0)
            elapsed = time.monotonic() - last
            sleep_for = delay - elapsed
            if sleep_for > 0:
                time.sleep(sleep_for)
            # Record the access time *inside* the lock so other threads
            # targeting the same host see the updated timestamp
            self._last_access[host] = time.monotonic()

    def record_access(self, url: str) -> None:
        """
        Manually record a completed request to *url*.

        Call this after a successful or failed fetch so that
        wait_if_needed() has an accurate last-access timestamp even when
        the fetch happens outside wait_if_needed().
        """
        host = self._host_of(url)
        lock = self._get_host_lock(host)
        with lock:
            self._last_access[host] = time.monotonic()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _host_of(self, url: str) -> str:
        """Extract the netloc (scheme + host + optional port) from *url*."""
        from urllib.parse import urlparse
        p = urlparse(url)
        # Use scheme+netloc as the key so http:// and https:// are distinct
        return f"{p.scheme}://{p.netloc}"

    def _get_host_lock(self, host: str) -> threading.Lock:
        """Return (creating if necessary) the per-host lock."""
        with self._global_lock:
            if host not in self._host_locks:
                self._host_locks[host] = threading.Lock()
            return self._host_locks[host]

    def _get_robots(self, host: str) -> Protego | None:
        """
        Return the cached Protego parser for *host*, fetching it if needed.

        Must be called with the host lock held.
        """
        if host in self._robots:
            return self._robots[host]

        robots_url = f"{host}/robots.txt"
        try:
            resp = requests.get(
                robots_url,
                headers={"User-Agent": USER_AGENT},
                timeout=ROBOTS_FETCH_TIMEOUT,
                allow_redirects=True,
            )
            if resp.status_code == 200:
                parser = Protego.parse(resp.text)
            else:
                # 404 or other status -> treat as no restrictions
                parser = None
        except Exception as exc:
            logger.debug("Could not fetch robots.txt for %s: %s", host, exc)
            parser = None

        self._robots[host] = parser
        return parser

    def _crawl_delay(self, host: str) -> float:
        """
        Return the effective crawl delay (seconds) for *host*.

        Must be called with the host lock held.
        """
        robots = self._robots.get(host)
        if robots is None:
            return DEFAULT_DELAY

        delay = robots.crawl_delay(USER_AGENT)
        if delay is None:
            return DEFAULT_DELAY

        # Never go below the mandatory 100 ms floor
        return max(DEFAULT_DELAY, float(delay))
