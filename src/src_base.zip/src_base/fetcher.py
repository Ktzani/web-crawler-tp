"""
fetcher.py
----------
Responsible for making HTTP GET requests and returning the raw HTML content.

Key behaviours:
  - Sends a descriptive User-Agent so webmasters can identify the crawler.
  - Uses a HEAD request first when the Content-Type cannot be inferred from
    the URL, avoiding downloading non-HTML resources (images, PDFs, …).
  - Only proceeds to a full GET when the MIME type is text/html (Selection
    Policy requirement).
  - Returns a FetchResult dataclass with all metadata needed by the other
    modules (URL after redirects, status, HTML, headers, timestamp).
"""

import time
import logging
from dataclasses import dataclass, field

import requests
from requests import Response
from requests.exceptions import RequestException

logger = logging.getLogger(__name__)

# Reuse the same User-Agent string declared in politeness.py
USER_AGENT: str = "IR-Crawler/1.0 (+https://dcc.ufmg.br)"

# Maximum response size to download (10 MB). Larger pages are skipped.
MAX_CONTENT_LENGTH: int = 10 * 1024 * 1024

# Request timeout in seconds (connect, read)
REQUEST_TIMEOUT: tuple[int, int] = (10, 30)

# HTTP headers sent on every request
DEFAULT_HEADERS: dict[str, str] = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-us,en;q=0.5",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
}


@dataclass
class FetchResult:
    """
    Holds all information about a single fetch attempt.

    Attributes
    ----------
    url         : Original URL requested (before any redirects).
    final_url   : URL after following redirects (may differ from url).
    status_code : HTTP status code, or -1 on network error.
    html        : Raw HTML bytes, or None if the page was not fetched.
    headers     : Response headers dict (empty on error).
    timestamp   : Unix time (int) when the fetch was initiated.
    error       : Human-readable error message, or empty string on success.
    """
    url: str
    final_url: str = ""
    status_code: int = -1
    html: bytes | None = None
    headers: dict = field(default_factory=dict)
    timestamp: int = 0
    error: str = ""

    @property
    def ok(self) -> bool:
        """True if a valid HTML page was retrieved."""
        return self.html is not None and self.status_code == 200


class Fetcher:
    """
    Stateless HTTP fetcher.

    Uses a requests.Session for connection-pool reuse across calls,
    which reduces TCP handshake overhead when crawling the same host
    from multiple worker threads.

    Note: requests.Session is *not* thread-safe for concurrent use from
    multiple threads. Each worker thread should therefore use its own
    Fetcher instance (instantiated inside the thread function).
    """

    def __init__(self) -> None:
        self._session = requests.Session()
        self._session.headers.update(DEFAULT_HEADERS)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def fetch(self, url: str) -> FetchResult:
        """
        Fetch *url* and return a FetchResult.

        Workflow:
          1. Record Unix timestamp.
          2. Perform GET request with stream=True.
          3. Check Content-Type header -> reject non-HTML.
          4. Check Content-Length header -> skip oversized pages.
          5. Read up to MAX_CONTENT_LENGTH bytes.

        Parameters
        ----------
        url : str
            Absolute URL to fetch.

        Returns
        -------
        FetchResult
            Populated dataclass; check .ok before using .html.
        """
        timestamp = int(time.time())
        result = FetchResult(url=url, timestamp=timestamp)

        try:
            response: Response = self._session.get(
                url,
                timeout=REQUEST_TIMEOUT,
                allow_redirects=True,
                stream=True,           # Don't download body until we check headers
            )

            result.final_url = response.url
            result.status_code = response.status_code
            result.headers = dict(response.headers)

            # Only process 200 OK responses
            if response.status_code != 200:
                result.error = f"HTTP {response.status_code}"
                return result

            # --- Selection Policy: only text/html ---
            content_type = response.headers.get("Content-Type", "")
            if not self._is_html(content_type):
                result.error = f"Non-HTML content type: {content_type}"
                return result

            # --- Size guard ---
            content_length = int(response.headers.get("Content-Length", 0))
            if content_length > MAX_CONTENT_LENGTH:
                result.error = f"Content-Length too large: {content_length}"
                return result

            # --- Read body (bounded) ---
            html = self._read_bounded(response)
            if html is None:
                result.error = "Response body exceeded size limit"
                return result

            result.html = html

        except RequestException as exc:
            result.error = str(exc)
            logger.debug("Fetch error for %s: %s", url, exc)

        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_html(content_type: str) -> bool:
        """Return True if the MIME type indicates an HTML document."""
        ct = content_type.lower()
        return "text/html" in ct or "application/xhtml+xml" in ct

    @staticmethod
    def _read_bounded(response: Response) -> bytes | None:
        """
        Read the response body up to MAX_CONTENT_LENGTH bytes.

        Returns None if the content exceeds the limit.
        """
        chunks: list[bytes] = []
        total = 0
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                total += len(chunk)
                if total > MAX_CONTENT_LENGTH:
                    return None
                chunks.append(chunk)
        return b"".join(chunks)

    def close(self) -> None:
        """Release the underlying connection pool."""
        self._session.close()
