"""
crawler.py
----------
Entry point for the Web Crawler (Programming Assignment #1).

Usage
-----
    python3 crawler.py -s <SEEDS_FILE> -n <LIMIT> [-d]

Arguments
---------
    -s  Path to a file containing seed URLs (one per line).
    -n  Target number of unique pages to crawl.
    -d  (optional) Debug mode: print a JSON record for each crawled page.

Architecture
------------
    A ThreadPoolExecutor with NUM_THREADS workers shares a single Frontier
    and a single StorageManager (both thread-safe). Each worker thread owns
    its own Fetcher instance (requests.Session is not thread-safe for
    concurrent use, so one session per thread avoids races).

    The main thread monitors a shared counter protected by a threading.Event.
    Once the counter reaches LIMIT, the done_event is set and workers exit
    their loops gracefully.

Thread count rationale
----------------------
    Crawling is I/O-bound: each thread spends most of its time waiting for
    network responses. With a Ryzen 9 5900X (12 cores / 24 threads) and a
    fast SSD, 32 threads provides a good balance:
      - More than the 24 physical threads (safe for I/O-bound workloads).
      - Not so many that the politeness delays are totally swamped.
    This value can be tuned experimentally and reported in the assignment
    documentation (speedup vs. number of threads graph).
"""

import argparse
import json
import logging
import sys
import threading
from concurrent.futures import ThreadPoolExecutor

from frontier import Frontier
from fetcher import Fetcher
from parser import Parser
from politeness import PolitenessManager
from storage import StorageManager

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

NUM_THREADS: int = 32          # Worker threads (I/O-bound -> safe above core count)
LOG_FORMAT: str = "%(asctime)s [%(levelname)s] %(threadName)s: %(message)s"

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

logging.basicConfig(level=logging.INFO, format=LOG_FORMAT, stream=sys.stderr)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Worker function
# ---------------------------------------------------------------------------

def worker(
    frontier: Frontier,
    politeness: PolitenessManager,
    storage: StorageManager,
    counter: list[int],         # [crawled_count]  — mutable single-element list
    counter_lock: threading.Lock,
    limit: int,
    done_event: threading.Event,
    debug: bool,
) -> None:
    """
    Worker coroutine executed by each thread in the pool.

    Each iteration:
      1. Get next URL from the frontier (blocks up to 1 s).
      2. Check robots.txt via PolitenessManager.
      3. Wait for the per-host delay.
      4. Fetch the page.
      5. Parse links + text.
      6. Write to WARC.
      7. Enqueue outlinks in the frontier.
      8. Optionally print debug JSON.
      9. Increment the shared counter; set done_event if limit reached.
    """
    # Each thread gets its own Fetcher (one requests.Session per thread)
    fetcher = Fetcher()
    parser = Parser()

    try:
        while not done_event.is_set():
            # --- 1. Get URL ---
            url = frontier.get(timeout=1.0)
            if url is None:
                # Frontier temporarily empty; spin and retry
                continue

            try:
                # --- 2. Robots check ---
                if not politeness.is_allowed(url):
                    logger.debug("Disallowed by robots.txt: %s", url)
                    frontier.task_done()
                    continue

                # --- 3. Politeness delay ---
                politeness.wait_if_needed(url)

                # --- 4. Fetch ---
                result = fetcher.fetch(url)

                if not result.ok:
                    logger.debug("Skip (%s): %s", result.error, url)
                    frontier.task_done()
                    continue

                # --- 5. Parse ---
                parsed = parser.parse(result.html, base_url=result.final_url)

                # --- 6. Write to WARC ---
                storage.write(
                    url=result.final_url,
                    html=result.html,
                    http_headers=result.headers,
                )

                # --- 7. Enqueue outlinks ---
                for link in parsed.outlinks:
                    frontier.add(link)

                # --- 8. Debug output ---
                if debug:
                    record = {
                        "URL": result.final_url,
                        "Title": parsed.title,
                        "Text": parsed.text_snippet,
                        "Timestamp": result.timestamp,
                    }
                    # json.dumps is thread-safe; print is guarded by the GIL
                    print(json.dumps(record, ensure_ascii=False), flush=True)

                # --- 9. Increment counter ---
                with counter_lock:
                    counter[0] += 1
                    crawled = counter[0]
                    if crawled % 1000 == 0:
                        logger.info(
                            "Progress: %d / %d pages crawled "
                            "(frontier size: ~%d)",
                            crawled, limit, frontier.queue_size(),
                        )
                    if crawled >= limit:
                        done_event.set()

            finally:
                frontier.task_done()

    finally:
        fetcher.close()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    ap = argparse.ArgumentParser(
        description="IR Assignment #1 — Multithreaded Web Crawler"
    )
    ap.add_argument(
        "-s", "--seeds", required=True,
        help="Path to seed URL file (one URL per line).",
    )
    ap.add_argument(
        "-n", "--limit", required=True, type=int,
        help="Target number of unique pages to crawl.",
    )
    ap.add_argument(
        "-d", "--debug", action="store_true",
        help="Print a JSON record for each crawled page (stdout).",
    )
    return ap.parse_args()


def load_seeds(path: str) -> list[str]:
    """
    Read seed URLs from a plain-text file.

    Blank lines and lines starting with '#' are ignored.
    """
    seeds: list[str] = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                url = line.strip()
                if url and not url.startswith("#"):
                    seeds.append(url)
    except FileNotFoundError:
        logger.error("Seeds file not found: %s", path)
        sys.exit(1)

    if not seeds:
        logger.error("Seeds file is empty: %s", path)
        sys.exit(1)

    logger.info("Loaded %d seed URLs from %s", len(seeds), path)
    return seeds


def main() -> None:
    args = parse_args()

    if args.debug:
        # Suppress INFO logs to stderr so they don't mix with JSON stdout
        logging.getLogger().setLevel(logging.WARNING)

    # --- Initialise shared components ---
    seeds = load_seeds(args.seeds)
    frontier = Frontier(seeds)
    politeness = PolitenessManager()
    storage = StorageManager()

    # Shared counter (wrapped in a list so it's mutable across threads)
    counter: list[int] = [0]
    counter_lock = threading.Lock()
    done_event = threading.Event()

    logger.info(
        "Starting crawl: limit=%d, threads=%d, debug=%s",
        args.limit, NUM_THREADS, args.debug,
    )

    # --- Launch thread pool ---
    with ThreadPoolExecutor(
        max_workers=NUM_THREADS, thread_name_prefix="crawler"
    ) as executor:
        futures = [
            executor.submit(
                worker,
                frontier,
                politeness,
                storage,
                counter,
                counter_lock,
                args.limit,
                done_event,
                args.debug,
            )
            for _ in range(NUM_THREADS)
        ]

        # Wait for all threads to finish (they exit when done_event is set)
        for f in futures:
            try:
                f.result()
            except Exception as exc:
                logger.error("Worker raised an exception: %s", exc)

    # --- Finalise ---
    storage.close()
    logger.info(
        "Crawl complete. Total pages stored: %d / %d requested.",
        storage.total_pages, args.limit,
    )


if __name__ == "__main__":
    main()
