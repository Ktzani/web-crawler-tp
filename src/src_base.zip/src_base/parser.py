"""
parser.py
---------
Parses raw HTML to extract:
  - Outlinks (absolute URLs) to be added to the frontier.
  - Page title (for debug output).
  - Visible text (first 20 words, for debug output).

Uses BeautifulSoup with the built-in "html.parser" backend (no lxml
dependency) for robustness on malformed real-world HTML.

Complexity:
  - Parsing          : O(n) in the size of the HTML document.
  - Link extraction  : O(k) where k is the number of <a> tags.
  - Text extraction  : O(n) for get_text() traversal; O(w) for word split.
"""

import logging
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# URL schemes we are willing to follow
ALLOWED_SCHEMES: frozenset[str] = frozenset({"http", "https"})


class Parser:
    """
    Stateless HTML parser.

    All methods are pure functions of their inputs and are safe to call
    from multiple threads simultaneously (no shared mutable state).
    """

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def parse(self, html: bytes, base_url: str) -> "ParseResult":
        """
        Parse *html* and return a ParseResult.

        Parameters
        ----------
        html     : Raw HTML bytes from the fetcher.
        base_url : The URL from which *html* was fetched (used to resolve
                   relative links).

        Returns
        -------
        ParseResult
            Contains title, first-20-word snippet, and list of outlinks.
        """
        soup = BeautifulSoup(html, "html.parser")

        title = self._extract_title(soup)
        text_snippet = self._extract_text_snippet(soup, n_words=20)
        outlinks = self._extract_links(soup, base_url)

        return ParseResult(
            title=title,
            text_snippet=text_snippet,
            outlinks=outlinks,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_title(soup: BeautifulSoup) -> str:
        """Return the page title, stripped of extra whitespace."""
        tag = soup.find("title")
        if tag and tag.string:
            return tag.string.strip()
        # Fallback: first <h1>
        h1 = soup.find("h1")
        if h1:
            return h1.get_text(separator=" ", strip=True)
        return ""

    @staticmethod
    def _extract_text_snippet(soup: BeautifulSoup, n_words: int = 20) -> str:
        """
        Return the first *n_words* words of visible page text.

        Invisible elements (scripts, styles, meta tags) are removed before
        extracting text to avoid polluting the snippet with JS code or CSS.
        """
        # Remove non-visible elements in-place
        for tag in soup(["script", "style", "noscript", "head", "meta", "link"]):
            tag.decompose()

        text = soup.get_text(separator=" ", strip=True)
        words = text.split()
        return " ".join(words[:n_words])

    @staticmethod
    def _extract_links(soup: BeautifulSoup, base_url: str) -> list[str]:
        """
        Extract all absolute, unique outlinks from <a href="..."> tags.

        Filters:
          - Only http:// and https:// schemes (no mailto:, javascript:, …)
          - Strips fragments (#section) as they point to the same document.
          - Deduplicates within this page (global dedup is in Frontier).

        Parameters
        ----------
        soup     : Parsed BeautifulSoup tree.
        base_url : Used by urljoin to resolve relative hrefs.
        """
        seen_on_page: set[str] = set()
        links: list[str] = []

        for tag in soup.find_all("a", href=True):
            href: str = tag["href"].strip()

            # Resolve relative URLs against the base URL
            absolute = urljoin(base_url, href)

            # Strip fragment (the part after #)
            parsed = urlparse(absolute)
            clean = parsed._replace(fragment="").geturl()

            # Filter by scheme
            if parsed.scheme not in ALLOWED_SCHEMES:
                continue

            # Deduplicate within this page
            if clean in seen_on_page:
                continue
            seen_on_page.add(clean)

            links.append(clean)

        return links


class ParseResult:
    """
    Result of parsing a single HTML page.

    Attributes
    ----------
    title        : Page title (may be empty if not found).
    text_snippet : First 20 visible words (used in debug output).
    outlinks     : List of absolute URLs found on the page.
    """

    __slots__ = ("title", "text_snippet", "outlinks")

    def __init__(self, title: str, text_snippet: str, outlinks: list[str]) -> None:
        self.title = title
        self.text_snippet = text_snippet
        self.outlinks = outlinks

    def __repr__(self) -> str:
        return (
            f"ParseResult(title={self.title!r}, "
            f"links={len(self.outlinks)}, "
            f"snippet={self.text_snippet[:40]!r})"
        )
