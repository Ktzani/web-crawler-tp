"""
frontier.py
-----------
Manages the BFS URL frontier for the crawler.

Data structures:
  - queue.Queue  : thread-safe FIFO queue (BFS order). O(1) enqueue/dequeue.
  - set          : O(1) average-case lookup for already-seen URLs.
  - threading.Lock: guards the seen-set so multiple threads don't race on it.

Why BFS?
  BFS (breadth-first search) prioritises URLs discovered early, which keeps
  the crawl broad across many domains before going deep into any single site.
  This maximises diversity in the final corpus.
"""

import queue
import threading
from url_normalize import url_normalize


class Frontier:
    """
    Thread-safe BFS frontier.

    Attributes
    ----------
    _queue : queue.Queue
        The actual work queue consumed by worker threads.
    _seen  : set[str]
        Normalised URLs already added to the frontier (or crawled).
    _lock  : threading.Lock
        Protects _seen from concurrent modification.
    """

    def __init__(self, seeds: list[str]) -> None:
        """
        Initialise the frontier with a list of seed URLs.

        Parameters
        ----------
        seeds : list[str]
            Seed URLs read from the -s file.
        """
        self._queue: queue.Queue[str] = queue.Queue()
        self._seen: set[str] = set()
        self._lock = threading.Lock()

        # Enqueue every seed (deduplication is applied even here)
        for url in seeds:
            self.add(url)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def add(self, url: str) -> bool:
        """
        Normalise *url* and add it to the queue if not seen before.

        Normalisation (via url-normalize) handles:
          - lowercasing scheme and host
          - removing default ports
          - percent-encoding consistency
          - removing empty query strings / fragments

        Parameters
        ----------
        url : str
            Raw URL extracted from a page.

        Returns
        -------
        bool
            True if the URL was new and successfully enqueued.
        """
        try:
            norm = url_normalize(url)
        except Exception:
            # Malformed URLs are silently dropped
            return False

        with self._lock:
            if norm in self._seen:
                return False
            self._seen.add(norm)

        self._queue.put(norm)
        return True

    def get(self, timeout: float = 1.0) -> str | None:
        """
        Retrieve the next URL from the frontier.

        Parameters
        ----------
        timeout : float
            Seconds to block waiting for an item before returning None.

        Returns
        -------
        str | None
            The next URL, or None if the queue was empty for *timeout* seconds.
        """
        try:
            return self._queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def task_done(self) -> None:
        """Signal that the last URL retrieved with get() has been processed."""
        self._queue.task_done()

    def mark_seen(self, url: str) -> None:
        """
        Mark a URL as seen without enqueuing it.

        Useful for URLs that were fetched but should not be re-crawled
        (e.g. non-HTML resources detected after the request is made).
        """
        try:
            norm = url_normalize(url)
        except Exception:
            return
        with self._lock:
            self._seen.add(norm)

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    def is_empty(self) -> bool:
        """Return True when no URLs are waiting to be crawled."""
        return self._queue.empty()

    def seen_count(self) -> int:
        """Return the total number of unique URLs ever added."""
        with self._lock:
            return len(self._seen)

    def queue_size(self) -> int:
        """Return the approximate number of URLs still pending."""
        return self._queue.qsize()
